@include('layouts.header')
@include('layouts.nav')
@include('layouts.sidebar')

@yield('main-container')

@include('layouts.footer')
