@include('layouts.header')
@include('layouts.nav')
@include('userlayout.sidebar')

@yield('main-container')

@include('layouts.footer')
