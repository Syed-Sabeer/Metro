<main class="main-content">
    <div class="sidebar-wrapper">
        <div class="sidebar sidebar-collapse" id="sidebar">
            <div class="sidebar__menu-group">
                <ul class="sidebar_nav">
                    {{-- <li class="menu-title mt-30">
                        <span>Applications</span>
                    </li> --}}

                    <li>
                        <a href="{{url('/')}}" class>
                            <span class="nav-icon uil uil-chat"></span>
                            <span class="menu-text">Dashboard</span>

                        </a>
                    </li>
 

                </ul>
            </div>
        </div>
    </div>
